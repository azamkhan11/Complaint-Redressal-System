import { Role } from "./role";

export class User {
    userName:string;
	fullName:string;
	userpassword:string;
	role:Role;
}
 