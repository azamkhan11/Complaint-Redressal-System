export class Role {

    roleName:string;
	roleDescription:string;
}
