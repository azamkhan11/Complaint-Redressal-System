import { Complaint } from './complaint';

describe('Complaint', () => {
  it('should create an instance', () => {
    expect(new Complaint()).toBeTruthy();
  });
});
